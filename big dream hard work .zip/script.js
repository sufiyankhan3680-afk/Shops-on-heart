// PAGE LOAD ANIMATION
document.addEventListener("DOMContentLoaded", () => {
  document.body.style.opacity = "0";
  document.body.style.transition = "opacity 1.2s ease-in-out";
  
  setTimeout(() => {
    document.body.style.opacity = "1";
  }, 200);
});


// PRODUCT HOVER EFFECT
const products = document.querySelectorAll(".product");

products.forEach(product => {
  product.addEventListener("mouseenter", () => {
    product.style.transform = "scale(1.05)";
    product.style.transition = "0.4s";
    product.style.boxShadow = "0 0 25px gold";
  });

  product.addEventListener("mouseleave", () => {
    product.style.transform = "scale(1)";
    product.style.boxShadow = "0 0 15px rgba(255,215,0,0.2)";
  });
});